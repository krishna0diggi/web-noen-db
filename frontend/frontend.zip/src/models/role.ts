export const ROLES = {
    USER:"user",
    ADMIN:"admin",
    SUPER_ADMIN:"superAdmin"   
}
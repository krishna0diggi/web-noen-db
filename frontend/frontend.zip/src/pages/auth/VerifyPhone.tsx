import React from 'react'

const VerifyPhone = () => {
  return (
    <div>
      
    </div>
  )
}

export default VerifyPhone
